// dependencies
import express from 'express';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import path from 'path';
import { fileURLToPath } from 'url';

// file path
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// express app
const app = express();
// middleware
app.use(bodyParser.urlencoded({ extended: true }));

// serve static files 
app.use(express.static(__dirname));

// mongodb connection 
mongoose.connect('mongodb://127.0.0.1:27017/restaurantDB').then(() => {
  console.log('Connected to MongoDB');
}).catch(err => {
  console.error('MongoDB connection error:', err);
});

// mongo schema
const userSchema = new mongoose.Schema({
  name: String,
  email: String,
});

// mongo model
const User = mongoose.model('User', userSchema);

// serving project.html 
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'project.html'));
});

// handling form submission
app.post('/submit', async (req, res) => {
  const { name, email } = req.body;

  try {
    
    const newUser = new User({ name, email });
    await newUser.save(); // 

    console.log('User saved:', newUser);
    res.send('<h1>Form submitted successfully!</h1>'); 
  } catch (error) {
    console.error('Error saving user:', error);
    res.status(500).send('<h1>Failed to save user data!</h1>'); 
  }
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
